KOTOR Republic Commando Mod
===========================

Modder:
--------
PRIME
Email: maroger@sympatico.ca
Website: warpedproductions.echonetwork.net


Description:
------------
This mod adds Republic Commando armours to KOTOR.  This is a set of armour suits and helmets, four
with paint schemes based on the Republic Commando game (http://lucasarts.com/games/swrepubliccommando/hud.html)
characters, and one generic white armour.  The armour and helmets each have stats and 
prerequisites.

Note: The TSL version of this mod can be found at the above website or pcgamemods.com.


Installation:
-------------

The armour can be installed using by the following steps:

Step 1. 
Extract all the files into the Override folder in the KOTOR directory.  

Step 2. 
To enable cheats, in your game directory edit swkotor.ini and under [Game Options] 
add EnableCheats=1.  Start the game then when playing press ' to bring down the console
prompt.  At the console prompt, type "giveitem <item name>" to add the item to the inventory.  

The item names are:
generic armour - rc_armour_70
Boss armour - rc_armour_71
Fixer armour - rc_armour_72
Sev armour - rc_armour_73
Scorch armour - rc_armour_74
generic helmet - rc_helmet_70
Boss helmet - rc_helmet_71
Fixer helmet - rc_helmet_72
Sev helmet - rc_helmet_73
Scorch helmet - rc_helmet_74


These can then be equiped by the player with the appropriate requirements (feats, sex, etc.) 
from the inventory screen.

Note: these armours are for male characters only


Uninstall
---------
Simply remove all the files from the Override directory.


Modding Information:
--------------------

Nothing here should conflict with other mods, unless they use armour with the same numbers (70-74).


Known Issues:
-------------

If you encounter issues, please report them to the email address specified 
above.  I will do what we can to correct them.

There are no known issues, but there may be problems with PC heads with "big hair".


Acknowledgements:
-----------------

Thanks to the AOTC/TC for allowing me to use the awesome Jedi Academy clone pilot 
helmet.  Also, thanks to bneezy for originally porting this helmet to KOTOR.

Thanks to Fred Tetra for creating the truly fantastic kotor editing tool.  Also 
a appreciative shout out to the many friendly folks at the Lucasforums' Holowan 
Laboratories board who have provided guidance and insight as well as answering 
numerous questions.

Finally, thanks to Bioware for making a truly kick ass game...


Conditions:
-----------
This mod is not supported in any way by Lucasarts or Bioware.

You may edit or modify these files for your own personal use.  

If you wish to use any or all of these files for you own public mod, please
contact PRIME for permission at the email addresses at the beginning of this file.  If 
I grant permission, please give me credit and include this readme file with your mod.  




